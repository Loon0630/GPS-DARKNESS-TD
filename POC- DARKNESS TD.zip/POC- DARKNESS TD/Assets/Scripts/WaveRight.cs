﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]

public class WaveRight
{
    public GameObject enemyRightPrefab;
    public int count;
    public float rate;
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]

public class Wave
{
    public GameObject enemyPrefab;
    public int count;
    public float rate;
}

/*public class WaveRight
{
    public GameObject enemyRightPrefab;
    public int count;
    public float rate;
}*/